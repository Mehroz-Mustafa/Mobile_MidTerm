package com.codemania.todolist_application;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity implements TodoListAdapter.SelectedList {

    TextView txv_EmptyList;
    ImageView img_EmptyList;
    RecyclerView rcv_TodoLists;

    ImageView img_Edit_List;
    CheckBox btn_Progress;
    FloatingActionButton fab_Add_List;

    TextView  txv_ListName;
    TextView  txv_ListItem;
    ImageView img_Del_List;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txv_EmptyList = findViewById(R.id.txv_empty_list);
        img_EmptyList = findViewById(R.id.img_empty_list);
        rcv_TodoLists = findViewById(R.id.rcv_todo_lists);

        img_Edit_List = findViewById(R.id.img_edit_list);
//        btn_Progress  = findViewById(R.id.btn_checklist);
        fab_Add_List = findViewById(R.id.fab_add_list);

        init();
    }

    @Override
    public void onInfoClick(int index) {
        btn_Progress.setOnClickListener(v -> {
            txv_ListName.setPaintFlags(txv_ListName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            txv_ListItem.setPaintFlags(txv_ListItem.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        });
        img_Edit_List.setOnClickListener(v -> {
            img_Del_List.setVisibility(View.VISIBLE);
        });
        fab_Add_List.setOnClickListener(v -> {

        });
    }

    void init() {
        if (TodoListArray.todoListModel.size() == 0) {
            rcv_TodoLists.setVisibility(View.INVISIBLE);
            img_EmptyList.setVisibility(View.VISIBLE);
            txv_EmptyList.setVisibility(View.VISIBLE);
        } else {
            rcv_TodoLists.setVisibility(View.VISIBLE);
            img_EmptyList.setVisibility(View.INVISIBLE);
            txv_EmptyList.setVisibility(View.INVISIBLE);
        }
    }
}