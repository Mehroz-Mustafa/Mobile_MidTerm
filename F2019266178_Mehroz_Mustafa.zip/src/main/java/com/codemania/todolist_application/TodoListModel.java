package com.codemania.todolist_application;

import java.util.ArrayList;

public class TodoListModel {

    String listName;
    ArrayList<String> listItem;
    String priority;

    public TodoListModel() {
        this.listName = null;
        this.priority = null;
        this.listItem = null;
    }
    public TodoListModel(String listName, ArrayList<String> listItems, String priority) {
        this.listName = listName;
        this.listItem = listItems;
        this.priority = priority;
    }

    public void setPriority(          String  priority) {
        this.priority = priority;
    }
    public void setListName(          String  listName) {
        this.listName = listName;
    }
    public void setListItem(ArrayList<String> listItem) {
        this.listItem = listItem;
    }

    public           String  getPriority() {
        return this.priority;
    }
    public           String  getListName() {
        return this.listName;
    }
    public ArrayList<String> getListItem() {
        return this.listItem;
    }

    @Override
    public String toString() {
        return "\nList Details:-" +
                "\n> " + this.priority +
                "\n> " + this.listName +
                "\n> " + this.listItem;
    }
}