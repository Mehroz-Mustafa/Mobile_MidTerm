package com.codemania.todolist_application;

import android.app.Application;

import java.util.ArrayList;

public class TodoListArray extends Application {
    public static ArrayList<TodoListModel> todoListModel;
    public static ArrayList<String> todoListItems;
    @Override
    public void onCreate() {
        super.onCreate();
        todoListItems = new ArrayList<>();
        todoListModel = new ArrayList<>();

        todoListItems.add("A");
        todoListModel.add(
                new TodoListModel("Task 1", todoListItems, "red"));

        todoListItems.add("B");
        todoListModel.add(
                new TodoListModel("Task 2", todoListItems, "yellow"));

        todoListItems.add("C");
        todoListModel.add(
                new TodoListModel("Task 3", todoListItems, "green"));

        todoListItems.add("D");
        todoListModel.add(
                new TodoListModel("Task 4", todoListItems, "yellow"));

        todoListItems.add("E");
        todoListModel.add(
                new TodoListModel("Task 5", todoListItems, "red"));
    }
}