package com.codemania.todolist_application;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TimePicker;

public class AddListFrag extends Fragment {

    EditText etv_list_name;
    EditText etv_list_item;

    RadioButton rbt_prior_tag;
    DatePicker dpk_enter_date;
    TimePicker tpk_enter_time;
    Switch     sbt_repeat_task;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public AddListFrag() {
        // Required empty public constructor
        etv_list_name   = findViewById(R.id.txv_list_name);
        etv_list_item   = findViewById(R.id.txv_list_item);

        rbt_prior_tag   = findViewById(R.id.rbp_prior_tag);
        dpk_enter_date  = findViewById(R.id.etd_enter_date);
        tpk_enter_time  = findViewById(R.id.ett_enter_time);
        sbt_repeat_task = findViewById(R.id.sbt_repeat_task);
    }

    public static AddListFrag newInstance(String param1, String param2) {
        AddListFrag fragment = new AddListFrag();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_list, container, false);
    }
}