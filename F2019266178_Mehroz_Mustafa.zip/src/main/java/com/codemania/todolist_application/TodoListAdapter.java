package com.codemania.todolist_application;

import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.codemania.todolist_application.TodoListAdapter.ViewHolder;
public class TodoListAdapter extends Adapter<ViewHolder> {

    SelectedList selectedList;
    ArrayList<TodoListModel> todoListModels;
    Context context;

    public TodoListAdapter(Context context, ArrayList<TodoListModel> list) {
        todoListModels = list;
        selectedList = (SelectedList) context;
        this.context = context;
    }

    public interface SelectedList {
        public void onInfoClick(int index);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txv_ListName;
        TextView txv_ListItem;
        ImageView img_priority;
        ImageView img_Del_List;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txv_ListName = itemView.findViewById(R.id.txv_list_name);
            txv_ListItem = itemView.findViewById(R.id.txv_list_item);
            img_priority = itemView.findViewById(R.id.img_prior_tag);
            img_Del_List = itemView.findViewById(R.id.img_del_list );
            img_Del_List.setVisibility(View.INVISIBLE);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_todo_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.txv_ListName.setText(todoListModels.get(position).getListName());
        holder.txv_ListName.setPaintFlags(holder.txv_ListName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        holder.txv_ListItem.setText(todoListModels.get(position).getListItem().toString());
        holder.img_Del_List.setImageResource(R.drawable.remove_);
        holder.itemView.setTag(todoListModels.get(position));

        switch (todoListModels.get(position).getPriority()) {
            case "red":
                holder.img_priority.setImageResource(R.drawable.red);
                break;
            case "yellow":
                holder.img_priority.setImageResource(R.drawable.yellow);
                break;
            case "green":
                holder.img_priority.setImageResource(R.drawable.green);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return todoListModels.size();
    }
}